def process_conv_with_stride(input_file, output_file, depth, height, width):
    # Đọc toàn bộ dữ liệu từ file hex vào một danh sách
    with open(input_file, 'r') as infile:
        lines = infile.readlines()
    
    # Chuyển đổi các giá trị từ file hex thành một danh sách 3D (depth, height, width)
    data = []
    idx = 0
    for h in range(height):  # Duyệt qua các hàng (height) trước
        row = []
        for w in range(width):  # Duyệt qua các cột (width)
            channel = []
            for d in range(depth):  # Duyệt qua chiều sâu (depth)
                # Đọc từng giá trị của phần tử tại (h, w, d)
                channel.append(int(lines[idx].strip(), 16))  # Lấy giá trị từ file hex
                idx += 1  # Chuyển đến phần tử tiếp theo trong file
            row.append(channel)
        data.append(row)

    # Đảm bảo dữ liệu có đúng kích thước
    assert len(data) == height and len(data[0]) == width and len(data[0][0]) == depth, "Kích thước dữ liệu không khớp"

    # Xử lý để lấy dữ liệu của Conv với stride = 2
    new_height = (height + 1) // 2  # Kích thước mới theo chiều cao sau khi có stride = 2
    new_width = (width + 1) // 2    # Kích thước mới theo chiều rộng sau khi có stride = 2
    
    new_data = []
    
    # Duyệt qua các channel
    for d in range(depth):
        new_channel = []
        # Duyệt qua chiều cao và chiều rộng với bước nhảy stride = 2
        for h in range(0, height, 2):  # Bỏ qua mỗi bước 2 trên chiều cao
            new_row = []
            for w in range(0, width, 2):  # Bỏ qua mỗi bước 2 trên chiều rộng
                new_row.append(data[h][w][d])  # Lấy giá trị pixel theo stride = 2
            new_channel.append(new_row)
        new_data.append(new_channel)

    # Ghi kết quả vào file hex mới
    with open(output_file, 'w') as outfile:
        for h in range(new_height):  # Duyệt qua chiều cao mới
            for w in range(new_width):  # Duyệt qua chiều rộng mới
                for d in range(depth):  # Duyệt qua chiều sâu
                    outfile.write(f"{new_data[d][h][w]:2X}\n")  # Ghi giá trị theo thứ tự channel -> height -> width

# Thí dụ sử dụng:
input_file = 'address/golden_2layers_folder/hex/ifm.hex'  # Tên file hex đầu vào
output_file = 'address/golden_2layers_folder/hex/ifm_stride2.hex'  # Tên file hex đầu ra
depth = 48  # Số lượng channel
height = 28  # Chiều cao (số hàng)
width = 28  # Chiều rộng (số cột)

process_conv_with_stride(input_file, output_file, depth, height, width)
